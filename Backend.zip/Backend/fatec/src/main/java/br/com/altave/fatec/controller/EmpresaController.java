package br.com.altave.fatec.controller;

import br.com.altave.fatec.model.Empresa;
import br.com.altave.fatec.service.EmpresaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/empresas")
public class EmpresaController {

    private final EmpresaService service;

    public EmpresaController(EmpresaService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Empresa>> listarTodas() {
        return ResponseEntity.ok(service.listarTodas());
    }

    @GetMapping("/{cnpj}")
    public ResponseEntity<Empresa> buscarPorCnpj(@PathVariable Long cnpj) {
        return service.buscarPorCnpj(cnpj)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Empresa> salvar(@RequestBody Empresa empresa) {
        return ResponseEntity.ok(service.salvar(empresa));
    }

    @DeleteMapping("/{cnpj}")
    public ResponseEntity<Void> excluir(@PathVariable Long cnpj) {
        service.excluir(cnpj);
        return ResponseEntity.noContent().build();
    }
}
