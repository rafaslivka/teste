package br.com.altave.fatec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FatecApplication {

	public static void main(String[] args) {
		SpringApplication.run(FatecApplication.class, args);
	}

}
