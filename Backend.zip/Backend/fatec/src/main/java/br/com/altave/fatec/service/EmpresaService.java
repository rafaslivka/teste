package br.com.altave.fatec.service;

import br.com.altave.fatec.model.Empresa;
import br.com.altave.fatec.repository.EmpresaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmpresaService {

    private final EmpresaRepository repository;

    public EmpresaService(EmpresaRepository repository) {
        this.repository = repository;
    }

    public List<Empresa> listarTodas() {
        return repository.findAll();
    }

    public Optional<Empresa> buscarPorCnpj(Long cnpj) {
        return repository.findByCnpj(cnpj);
    }

    public Empresa salvar(Empresa empresa) {
        return repository.save(empresa);
    }

    public void excluir(Long cnpj) {
        repository.deleteById(cnpj);
    }
}
